alter table OrdersBase alter column OrderDescription varchar(500) null;

GO

alter table OrderAttachments add RealFileName varchar(500) null;

go

ALTER TABLE [dbo].[OrderAttachments]  WITH CHECK ADD  CONSTRAINT [FK_OrderAttachments_AspNetUsers] FOREIGN KEY([AddedByUser])
REFERENCES [dbo].[AspNetUsers] ([Id])
GO

ALTER TABLE [dbo].[OrderAttachments] CHECK CONSTRAINT [FK_OrderAttachments_AspNetUsers]
GO


