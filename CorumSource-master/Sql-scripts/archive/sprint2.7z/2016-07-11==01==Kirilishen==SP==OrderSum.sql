ALTER TABLE [dbo].[OrderDogs] DROP CONSTRAINT [FK_OrderDogs_OrderClients]
GO


ALTER TABLE [dbo].[OrderDogs]  WITH CHECK ADD  CONSTRAINT [FK_OrderDogs_OrderClients] FOREIGN KEY([ClientId])
REFERENCES [dbo].[OrderClients] ([Id])
ON DELETE CASCADE
GO

ALTER TABLE [dbo].[OrderDogs] CHECK CONSTRAINT [FK_OrderDogs_OrderClients]
GO

alter table [dbo].[OrdersBase]
add Summ decimal(16,2) null;

GO

alter table [dbo].[OrdersBase]
add UseNotifications bit default(0);

GO