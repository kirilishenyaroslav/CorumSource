alter table [dbo].[OrderStatuses]
add Color varchar(20) not null default('#326496')