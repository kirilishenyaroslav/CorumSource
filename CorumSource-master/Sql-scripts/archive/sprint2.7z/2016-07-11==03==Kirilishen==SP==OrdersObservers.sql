

/****** Object:  Table [dbo].[OrderObservers]    Script Date: 7/11/2016 10:13:56 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[OrderObservers](
	[Id] [bigint] IDENTITY(1,1) NOT NULL,
	[OrderId] [bigint] NOT NULL,
	[userId] [nvarchar](128) NOT NULL,
 CONSTRAINT [PK_OrderObservers] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

ALTER TABLE [dbo].[OrderObservers]  WITH CHECK ADD  CONSTRAINT [FK_OrderObservers_AspNetUsers] FOREIGN KEY([userId])
REFERENCES [dbo].[AspNetUsers] ([Id])
ON DELETE CASCADE
GO

ALTER TABLE [dbo].[OrderObservers] CHECK CONSTRAINT [FK_OrderObservers_AspNetUsers]
GO

ALTER TABLE [dbo].[OrderObservers]  WITH CHECK ADD  CONSTRAINT [FK_OrderObservers_OrdersBase] FOREIGN KEY([OrderId])
REFERENCES [dbo].[OrdersBase] ([Id])
ON DELETE CASCADE
GO

ALTER TABLE [dbo].[OrderObservers] CHECK CONSTRAINT [FK_OrderObservers_OrdersBase]
GO


