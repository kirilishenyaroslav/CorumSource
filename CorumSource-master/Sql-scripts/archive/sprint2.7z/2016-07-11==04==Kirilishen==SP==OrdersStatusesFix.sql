

ALTER TABLE [dbo].[OrderStatusHistory] DROP CONSTRAINT [FK_OrderStatusHistory_OrdersBase]
GO

ALTER TABLE [dbo].[OrderStatusHistory]  WITH CHECK ADD  CONSTRAINT [FK_OrderStatusHistory_OrdersBase] FOREIGN KEY([OrderId])
REFERENCES [dbo].[OrdersBase] ([Id])
ON DELETE CASCADE
GO

ALTER TABLE [dbo].[OrderStatusHistory] CHECK CONSTRAINT [FK_OrderStatusHistory_OrdersBase]
GO


