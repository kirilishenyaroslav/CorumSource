
ALTER TABLE [dbo].[OrderStatuses] DROP CONSTRAINT [FK_OrderStatuses_OrderStatuses]
GO

ALTER TABLE [dbo].[OrderStatuses] DROP CONSTRAINT [FK_OrderStatuses_OrderStatuses2]
GO


alter table [dbo].[OrderStatuses]
drop column [NextStatusId];

GO

alter table [dbo].[OrderStatuses]
drop column [BeforeStatusId];

GO

