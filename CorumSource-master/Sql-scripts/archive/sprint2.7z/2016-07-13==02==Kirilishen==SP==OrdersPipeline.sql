

/****** Object:  Table [dbo].[OrderPipelineSteps]    Script Date: 7/13/2016 05:59:43 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[OrderPipelineSteps](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[FromStatus] [int] NOT NULL,
	[ToStatus] [int] NOT NULL,
	[AccessRoleId] [nvarchar](128) NOT NULL,
 CONSTRAINT [PK_OrderPipelineSteps] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

ALTER TABLE [dbo].[OrderPipelineSteps]  WITH CHECK ADD  CONSTRAINT [FK_OrderPipelineSteps_AspNetRoles] FOREIGN KEY([AccessRoleId])
REFERENCES [dbo].[AspNetRoles] ([Id])
ON DELETE CASCADE
GO

ALTER TABLE [dbo].[OrderPipelineSteps] CHECK CONSTRAINT [FK_OrderPipelineSteps_AspNetRoles]
GO

ALTER TABLE [dbo].[OrderPipelineSteps]  WITH CHECK ADD  CONSTRAINT [FK_OrderPipelineSteps_OrderStatuses] FOREIGN KEY([FromStatus])
REFERENCES [dbo].[OrderStatuses] ([Id])
ON DELETE CASCADE
GO

ALTER TABLE [dbo].[OrderPipelineSteps] CHECK CONSTRAINT [FK_OrderPipelineSteps_OrderStatuses]
GO

ALTER TABLE [dbo].[OrderPipelineSteps]  WITH CHECK ADD  CONSTRAINT [FK_OrderPipelineSteps_OrderStatuses1] FOREIGN KEY([ToStatus])
REFERENCES [dbo].[OrderStatuses] ([Id])
GO

ALTER TABLE [dbo].[OrderPipelineSteps] CHECK CONSTRAINT [FK_OrderPipelineSteps_OrderStatuses1]
GO


