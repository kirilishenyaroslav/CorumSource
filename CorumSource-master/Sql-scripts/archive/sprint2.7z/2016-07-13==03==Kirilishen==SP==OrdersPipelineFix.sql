

/****** Object:  Index [UniquePipelineStepsIndex]    Script Date: 7/13/2016 08:02:47 PM ******/
CREATE UNIQUE NONCLUSTERED INDEX [UniquePipelineStepsIndex] ON [dbo].[OrderPipelineSteps]
(
	[FromStatus] ASC,
	[ToStatus] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO

