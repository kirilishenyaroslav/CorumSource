

ALTER TABLE [dbo].[OrderAttachments] DROP CONSTRAINT [FK_OrderAttachments_OrdersBase]
GO

ALTER TABLE [dbo].[OrderAttachments]  WITH CHECK ADD  CONSTRAINT [FK_OrderAttachments_OrdersBase] FOREIGN KEY([OrderId])
REFERENCES [dbo].[OrdersBase] ([Id])
ON DELETE CASCADE
GO

ALTER TABLE [dbo].[OrderAttachments] CHECK CONSTRAINT [FK_OrderAttachments_OrdersBase]
GO


