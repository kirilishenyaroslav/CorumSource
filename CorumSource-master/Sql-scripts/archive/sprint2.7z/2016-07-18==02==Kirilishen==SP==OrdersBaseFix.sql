Alter table [dbo].[OrdersBase]
add CreatorPosition varchar(100) null;

GO

Alter table [dbo].[OrdersBase]
add CreatorContact varchar(100) null;

GO