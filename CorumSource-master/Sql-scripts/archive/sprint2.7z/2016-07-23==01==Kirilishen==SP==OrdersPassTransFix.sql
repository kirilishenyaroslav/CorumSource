alter table [dbo].[OrdersPassengerTransport]
add CarDetailInfo varchar(100) null;

GO

alter table [dbo].[OrdersPassengerTransport]
add CarDriverFio varchar(100) null;

GO

alter table [dbo].[OrdersPassengerTransport]
add CarDriverContactInfo varchar(100) null;

GO