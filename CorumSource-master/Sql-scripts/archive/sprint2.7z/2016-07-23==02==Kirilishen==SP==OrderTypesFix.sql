alter table [dbo].[OrderStatuses]
add AllowEditRegData bit null; 

GO

alter table [dbo].[OrderStatuses]
add AllowEditClientData bit null; 

GO

alter table [dbo].[OrderStatuses]
add AllowEditExecuterData bit null;

GO