ALTER TABLE [dbo].[DocsSnapshot] ALTER COLUMN QuantityPrihod decimal(18, 2) null
GO

ALTER TABLE [dbo].[DocsSnapshot] ALTER COLUMN QuantityRashod decimal(18, 2) null
GO

ALTER TABLE [dbo].[RestsSnapshot] ALTER COLUMN QuantityBefore decimal(18, 2) null
GO

ALTER TABLE [dbo].[RestsSnapshot] ALTER COLUMN QuantityAfter decimal(18, 2) null
GO


/****** Object:  StoredProcedure [dbo].[DocsSnapshotInsert]    Script Date: 25.07.2016 18:05:15 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- Batch submitted through debugger: SQLQuery40.sql|7|0|C:\Users\LASTOC~1\AppData\Local\Temp\~vs69A4.sql
-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
ALTER PROCEDURE [dbo].[DocsSnapshotInsert] 
@InnerPartyKey varchar(500),       @Producer varchar(500),       @Product varchar(100),
@Shifr varchar(50),                @Figure varchar(50),          @Measure varchar(50),
@Weight decimal(16,2),             @pType varchar(100),          @pGroup varchar(500),
@pRecieverPlan varchar(500),       @pRecieverFact varchar(500),  @RecieverGroupPlan varchar(100),
@InnerOrderNum varchar(50),        @OrderedBy varchar(500),      @OrderNum varchar(50),
@QuantityPrihod decimal(18,2),     @PE_Prihod decimal(18,2),     @PF_Prihod decimal(18,2),
@PCP_Prihod decimal(18,2),         @PCPC_Prihod decimal(18,2),   @FCP_Prihod decimal(18,2),
@FCPC_Prihod decimal(18,2),        @BP_Prihod decimal(18,2),     @PE_Rashod decimal(18,2),
@PF_Rashod decimal(18,2),          @PCP_Rashod decimal(18,2),    @PCPC_Rashod decimal(18,2),
@FCP_Rashod decimal(18,2),         @FCPC_Rashod decimal(18,2),   @BP_Rashod decimal(18,2),
@QuantityRashod decimal(18,2),     @Storage varchar(100),        @StorageCity varchar(50),
@StorageCountry varchar(10),       @�enter varchar(100),         @BalanceKeeper varchar(100),
@ReadyForSaleStatus varchar(50),   @ReserveStatus varchar(50),   @ProduceDate varchar(50),
@ReconcervationDate varchar(50),   @TermOnStorage int,           @PrihodDocType varchar(100),
@PrihodDocNum varchar(50),         @PrihodDocDate datetime,      @RashodDocType varchar(100),
@RashodDocNum varchar(50),         @RashodDocDate datetime,      @BalanceCurrency varchar(50),
@CurrencyIndexToUAH decimal(18,2), @id_snapshot INT
AS
BEGIN
  -- ��������� ������� ���������� (��� �������)
	SET NOCOUNT ON;
	
	-- ������� ����������
	INSERT INTO [dbo].[DocsSnapshot]
			([id_snapshot],      [InnerPartyKey],        [Producer]
			,[Product],          [Shifr],                [Figure]
			,[Measure],          [Weight],               [pType]
			,[pGroup],           [pRecieverPlan],        [pRecieverFact]
			,[RecieverGroupPlan], [InnerOrderNum],       [OrderedBy]
			,[OrderNum],         [QuantityPrihod],       [PE_Prihod]
			,[PF_Prihod],        [PCP_Prihod],           [PCPC_Prihod]
			,[FCP_Prihod],       [FCPC_Prihod],          [BP_Prihod]
			,[PE_Rashod],        [PF_Rashod],            [PCP_Rashod]
			,[PCPC_Rashod],      [FCP_Rashod],           [FCPC_Rashod]
			,[BP_Rashod],        [QuantityRashod],       [Storage]
			,[StorageCity],      [StorageCountry],       [�enter]
			,[BalanceKeeper],    [ReadyForSaleStatus],   [ReserveStatus]
			,[ProduceDate],      [ReconcervationDate],   [TermOnStorage]
			,[PrihodDocType],    [PrihodDocNum],         [PrihodDocDate]
			,[RashodDocType],    [RashodDocNum],         [RashodDocDate]
			,[BalanceCurrency],  [CurrencyIndexToUAH])
		VALUES
			(@id_snapshot,      @InnerPartyKey,      @Producer,       
			 @Product,   		@Shifr,              @Figure,         
			 @Measure,			@Weight,             @pType,          
			 @pGroup,			@pRecieverPlan,      @pRecieverFact,  
			 @RecieverGroupPlan,@InnerOrderNum,      @OrderedBy,      
			 @OrderNum,			@QuantityPrihod,     @PE_Prihod,     
			 @PF_Prihod,		@PCP_Prihod,         @PCPC_Prihod,    
			 @FCP_Prihod,		@FCPC_Prihod,        @BP_Prihod,      
			 @PE_Rashod,		@PF_Rashod,          @PCP_Rashod,    
			 @PCPC_Rashod,		@FCP_Rashod,         @FCPC_Rashod,    
			 @BP_Rashod,		@QuantityRashod,     @Storage,        
			 @StorageCity,		@StorageCountry,     @�enter,         
			 @BalanceKeeper,    @ReadyForSaleStatus, @ReserveStatus,  
			 @ProduceDate,		@ReconcervationDate, @TermOnStorage,  
			 @PrihodDocType,	@PrihodDocNum,       @PrihodDocDate,  
			 @RashodDocType, 	@RashodDocNum,       @RashodDocDate,  
			 @BalanceCurrency,	@CurrencyIndexToUAH)
END
GO
/****** Object:  StoredProcedure [dbo].[GetDocsDataBySnapshot]    Script Date: 04.07.2016 18:14:57 ******/
SET ANSI_NULLS ON
GO

/****** Object:  UserDefinedFunction [dbo].[GetDocsSummaryByInnerKey]    Script Date: 25.07.2016 18:07:46 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
ALTER FUNCTION [dbo].[GetDocsSummaryByInnerKey]( 
    @snapShotId int,
    @innerPartyKey varchar(500),
    @isPrihodDocs int 
)
RETURNS @DocsSummaryTable TABLE
   (
       Quantity     decimal(18,2),
       Mass         decimal(16,2),
       PE           decimal(16,2),       
       PF           decimal(16,2),          
       PCP          decimal(16,2),          
       PCPC         decimal(16,2), 
       FCP          decimal(16,2),         
       FCPC         decimal(16,2),
	   BP           decimal(16,2)
   )
AS
BEGIN

   IF (@isPrihodDocs=1)
   BEGIN

   INSERT @DocsSummaryTable
        SELECT SUM(D.QuantityPrihod), 
               SUM(D.Weight*D.QuantityPrihod),
               SUM(D.PE_Prihod),
               SUM(D.PF_Prihod),
               SUM(D.PCP_Prihod),
               SUM(D.PCPC_Prihod),
               SUM(D.FCP_Prihod),
               SUM(D.FCPC_Prihod),
               SUM(D.BP_Prihod)
          FROM [dbo].[DocsSnapshot] D
         where D.id_snapshot = @snapShotId
           and D.InnerPartyKey = @innerPartyKey
           
   END
   ELSE BEGIN
   INSERT @DocsSummaryTable
        SELECT SUM(D.QuantityRashod), 
               SUM(D.Weight*D.QuantityRashod),
               SUM(D.PE_Rashod),
               SUM(D.PF_Rashod),
               SUM(D.PCP_Rashod),
               SUM(D.PCPC_Rashod),
               SUM(D.FCP_Rashod),
               SUM(D.FCPC_Rashod),
               SUM(D.BP_Rashod)
          FROM [dbo].[DocsSnapshot] D
         where D.id_snapshot = @snapShotId
           and D.InnerPartyKey = @innerPartyKey
   END
   
   
      
           
   RETURN
END
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

ALTER FUNCTION [dbo].[GetProduceForPeriod]( 
    @PeriodDateBeg datetime,
	@PeriodDateEnd datetime,
	@OnDate datetime,

    @snapShotId int,
	@FilterStorageId varchar(500)=null,
    @FilterCenterId varchar(500)=null,
    @FilterRecieverPlanId varchar(500)=null,
    @FilterRecieverFactId varchar(500)=null,
    @FilterKeeperId varchar(500)=null,
    @FilterProducerId varchar(500)=null,

    @UseStorageFilter int=0,
    @UseCenterFilter int=0,
    @UseRecieverPlanFilter int=0,
    @UseRecieverFactFilter int=0,
    @UseKeeperFilter int=0,
    @UseProducerFilter int=0
)
RETURNS @RestInfoTable TABLE
   (
       [ProdByPeriod_Quantity]     decimal(18,2),
       [ProdByPeriod_Mass]         decimal(16,2),
       [ProdByPeriod_PE]           decimal(16,2),       
       [ProdByPeriod_PF]           decimal(16,2),          
       [ProdByPeriod_PCP]          decimal(16,2),          
       [ProdByPeriod_PCPC]         decimal(16,2), 
       [ProdByPeriod_FCP]          decimal(16,2),         
       [ProdByPeriod_FCPC]         decimal(16,2),
	   [ProdByPeriod_BP]           decimal(16,2)
   )
AS
BEGIN

   WITH tempRestInfo (Quantity,  Mass,    PE,    PF,   PCP,   PCPC,   FCP,   FCPC,  BP)
   AS
     (
		select  SUM(DC.QuantityPrihod), 
		        SUM(DC.QuantityPrihod*DC.Weight),
				SUM(DC.PE_Prihod),
				SUM(PF_Prihod),
				SUM(PCP_Prihod),
				SUM(PCPC_Prihod),
				SUM(FCP_Prihod),
				SUM(FCPC_Prihod),
				SUM(BP_Prihod)
		   FROM [dbo].[DocsSnapshot] DC
              WHERE (DC.id_snapshot=@snapShotId)
			    AND (DC.QuantityPrihod!=0)
		        AND (DC.QuantityRashod=0)
			    AND (convert(datetime, DC.PrihodDocDate, 104) between @PeriodDateBeg and @OnDate)
                AND ((@UseStorageFilter=0)        OR ((@UseStorageFilter=1)       and(DC.Storage=@FilterStorageId)))
                AND ((@UseCenterFilter=0)         OR ((@UseCenterFilter=1)        and(DC.�enter=@FilterCenterId))) 
                AND ((@UseRecieverPlanFilter=0)   OR ((@UseRecieverPlanFilter=1)  and(DC.pRecieverPlan=@FilterRecieverPlanId)))
                AND ((@UseRecieverFactFilter=0)   OR ((@UseRecieverFactFilter=1)  and(DC.pRecieverFact=@FilterRecieverFactId)))
                AND ((@UseKeeperFilter=0)         OR ((@UseKeeperFilter=1)        and(DC.BalanceKeeper=@FilterKeeperId))) 
                AND ((@UseProducerFilter=0)       OR ((@UseProducerFilter=1)      and(DC.Producer=@FilterProducerId)))

     )

   INSERT @RestInfoTable
        SELECT SUM(D.Quantity), 
               SUM(D.Mass),
               SUM(D.PE),
               SUM(D.PF),
               SUM(D.PCP),
               SUM(D.PCPC),
               SUM(D.FCP),
               SUM(D.FCPC),
               SUM(D.BP)
          FROM tempRestInfo D
   
   RETURN
END
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

ALTER FUNCTION [dbo].[GetProduceOnDate]( 
    @PeriodDateBeg datetime,
	@PeriodDateEnd datetime,
	@OnDate datetime,

    @snapShotId int,
	@FilterStorageId varchar(500)=null,
    @FilterCenterId varchar(500)=null,
    @FilterRecieverPlanId varchar(500)=null,
    @FilterRecieverFactId varchar(500)=null,
    @FilterKeeperId varchar(500)=null,
    @FilterProducerId varchar(500)=null,

    @UseStorageFilter int=0,
    @UseCenterFilter int=0,
    @UseRecieverPlanFilter int=0,
    @UseRecieverFactFilter int=0,
    @UseKeeperFilter int=0,
    @UseProducerFilter int=0
)
RETURNS @RestInfoTable TABLE
   (
       [ProdOnDate_Quantity]     decimal(18,2),
       [ProdOnDate_Mass]         decimal(16,2),
       [ProdOnDate_PE]           decimal(16,2),       
       [ProdOnDate_PF]           decimal(16,2),          
       [ProdOnDate_PCP]          decimal(16,2),          
       [ProdOnDate_PCPC]         decimal(16,2), 
       [ProdOnDate_FCP]          decimal(16,2),         
       [ProdOnDate_FCPC]         decimal(16,2),
	   [ProdOnDate_BP]           decimal(16,2)
   )
AS
BEGIN

   WITH tempRestInfo (Quantity,  Mass,    PE,    PF,   PCP,   PCPC,   FCP,   FCPC,  BP)
   AS
     (
		select  SUM(DC.QuantityPrihod), 
		        SUM(DC.QuantityPrihod*DC.Weight),
				SUM(DC.PE_Prihod),
				SUM(PF_Prihod),
				SUM(PCP_Prihod),
				SUM(PCPC_Prihod),
				SUM(FCP_Prihod),
				SUM(FCPC_Prihod),
				SUM(BP_Prihod)
		   FROM [dbo].[DocsSnapshot] DC
              WHERE (DC.id_snapshot=@snapShotId)
			    AND (DC.QuantityPrihod!=0)
		        AND (DC.QuantityRashod=0)
			    AND (convert(datetime, DC.PrihodDocDate, 104) = @OnDate)
                AND ((@UseStorageFilter=0)        OR ((@UseStorageFilter=1)       and(DC.Storage=@FilterStorageId)))
                AND ((@UseCenterFilter=0)         OR ((@UseCenterFilter=1)        and(DC.�enter=@FilterCenterId))) 
                AND ((@UseRecieverPlanFilter=0)   OR ((@UseRecieverPlanFilter=1)  and(DC.pRecieverPlan=@FilterRecieverPlanId)))
                AND ((@UseRecieverFactFilter=0)   OR ((@UseRecieverFactFilter=1)  and(DC.pRecieverFact=@FilterRecieverFactId)))
                AND ((@UseKeeperFilter=0)         OR ((@UseKeeperFilter=1)        and(DC.BalanceKeeper=@FilterKeeperId))) 
                AND ((@UseProducerFilter=0)       OR ((@UseProducerFilter=1)      and(DC.Producer=@FilterProducerId)))

     )

   INSERT @RestInfoTable
        SELECT SUM(D.Quantity), 
               SUM(D.Mass),
               SUM(D.PE),
               SUM(D.PF),
               SUM(D.PCP),
               SUM(D.PCPC),
               SUM(D.FCP),
               SUM(D.FCPC),
               SUM(D.BP)
          FROM tempRestInfo D
   
   RETURN
END
GO

/****** Object:  UserDefinedFunction [dbo].[GetRestsOnDate]    Script Date: 25.07.2016 18:13:19 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

ALTER FUNCTION [dbo].[GetRestsOnDate]( 
    @PeriodDateBeg datetime,
	@PeriodDateEnd datetime,
	@OnDate datetime,

    @snapShotId int,
	@FilterStorageId varchar(500)=null,
    @FilterCenterId varchar(500)=null,
    @FilterRecieverPlanId varchar(500)=null,
    @FilterRecieverFactId varchar(500)=null,
    @FilterKeeperId varchar(500)=null,
    @FilterProducerId varchar(500)=null,

    @UseStorageFilter int=0,
    @UseCenterFilter int=0,
    @UseRecieverPlanFilter int=0,
    @UseRecieverFactFilter int=0,
    @UseKeeperFilter int=0,
    @UseProducerFilter int=0
)
RETURNS @RestInfoTable TABLE
   (
       [Quantity_OnDate]     decimal(18,2),
       [Mass_OnDate]         decimal(16,2),
       [PE_OnDate]           decimal(16,2),       
       [PF_OnDate]           decimal(16,2),          
       [PCP_OnDate]          decimal(16,2),          
       [PCPC_OnDate]         decimal(16,2), 
       [FCP_OnDate]          decimal(16,2),         
       [FCPC_OnDate]         decimal(16,2),
	   [BP_OnDate]           decimal(16,2)
   )
AS
BEGIN

   WITH tempRestInfo (Quantity,  Mass,    PE,    PF,   PCP,   PCPC,   FCP,   FCPC,  BP)
   AS
     (
         select SUM(DC.QuantityBefore), 
		        SUM(DC.QuantityBefore*DC.Weight),
				SUM(DC.PE_Before),
				SUM(PF_Before),
				SUM(PCP_Before),
				SUM(PCPC_Before),
				SUM(FCP_Before),
				SUM(FCPC_Before),
				SUM(BP_Before)
		   FROM [dbo].[RestsSnapshot] DC
              WHERE (DC.id_snapshot=@snapShotId)
                AND ((@UseStorageFilter=0)        OR ((@UseStorageFilter=1)       and(DC.Storage=@FilterStorageId)))
                AND ((@UseCenterFilter=0)         OR ((@UseCenterFilter=1)        and(DC.�enter=@FilterCenterId))) 
                AND ((@UseRecieverPlanFilter=0)   OR ((@UseRecieverPlanFilter=1)  and(DC.pRecieverPlan=@FilterRecieverPlanId)))
                AND ((@UseRecieverFactFilter=0)   OR ((@UseRecieverFactFilter=1)  and(DC.pRecieverFact=@FilterRecieverFactId)))
                AND ((@UseKeeperFilter=0)         OR ((@UseKeeperFilter=1)        and(DC.BalanceKeeper=@FilterKeeperId))) 
                AND ((@UseProducerFilter=0)       OR ((@UseProducerFilter=1)      and(DC.Producer=@FilterProducerId)))



		 union

         select SUM(DC.QuantityPrihod), 
		        SUM(DC.QuantityPrihod*DC.Weight),
				SUM(DC.PE_Prihod),
				SUM(PF_Prihod),
				SUM(PCP_Prihod),
				SUM(PCPC_Prihod),
				SUM(FCP_Prihod),
				SUM(FCPC_Prihod),
				SUM(BP_Prihod)
		   FROM [dbo].[DocsSnapshot] DC
              WHERE (DC.id_snapshot=@snapShotId)
			    AND (DC.QuantityPrihod!=0)
		        AND (DC.QuantityRashod=0)
			    AND (convert(datetime, DC.PrihodDocDate, 104) between @PeriodDateBeg and DATEADD(day, -1, @OnDate))
                AND ((@UseStorageFilter=0)        OR ((@UseStorageFilter=1)       and(DC.Storage=@FilterStorageId)))
                AND ((@UseCenterFilter=0)         OR ((@UseCenterFilter=1)        and(DC.�enter=@FilterCenterId))) 
                AND ((@UseRecieverPlanFilter=0)   OR ((@UseRecieverPlanFilter=1)  and(DC.pRecieverPlan=@FilterRecieverPlanId)))
                AND ((@UseRecieverFactFilter=0)   OR ((@UseRecieverFactFilter=1)  and(DC.pRecieverFact=@FilterRecieverFactId)))
                AND ((@UseKeeperFilter=0)         OR ((@UseKeeperFilter=1)        and(DC.BalanceKeeper=@FilterKeeperId))) 
                AND ((@UseProducerFilter=0)       OR ((@UseProducerFilter=1)      and(DC.Producer=@FilterProducerId)))


		union

		select  -SUM(DC.QuantityRashod), 
		        -SUM(DC.QuantityRashod*DC.Weight),
				-SUM(DC.PE_Rashod),
				-SUM(PF_Rashod),
				-SUM(PCP_Rashod),
				-SUM(PCPC_Rashod),
				-SUM(FCP_Rashod),
				-SUM(FCPC_Rashod),
				-SUM(BP_Rashod)
		   FROM [dbo].[DocsSnapshot] DC
              WHERE (DC.id_snapshot=@snapShotId)
			    AND (DC.QuantityPrihod=0)
		        AND (DC.QuantityRashod!=0)
			    AND (convert(datetime, DC.RashodDocDate, 104) between @PeriodDateBeg and DATEADD(day, -1, @OnDate))
                AND ((@UseStorageFilter=0)        OR ((@UseStorageFilter=1)       and(DC.Storage=@FilterStorageId)))
                AND ((@UseCenterFilter=0)         OR ((@UseCenterFilter=1)        and(DC.�enter=@FilterCenterId))) 
                AND ((@UseRecieverPlanFilter=0)   OR ((@UseRecieverPlanFilter=1)  and(DC.pRecieverPlan=@FilterRecieverPlanId)))
                AND ((@UseRecieverFactFilter=0)   OR ((@UseRecieverFactFilter=1)  and(DC.pRecieverFact=@FilterRecieverFactId)))
                AND ((@UseKeeperFilter=0)         OR ((@UseKeeperFilter=1)        and(DC.BalanceKeeper=@FilterKeeperId))) 
                AND ((@UseProducerFilter=0)       OR ((@UseProducerFilter=1)      and(DC.Producer=@FilterProducerId)))

     )

   INSERT @RestInfoTable
        SELECT SUM(D.Quantity), 
               SUM(D.Mass),
               SUM(D.PE),
               SUM(D.PF),
               SUM(D.PCP),
               SUM(D.PCPC),
               SUM(D.FCP),
               SUM(D.FCPC),
               SUM(D.BP)
          FROM tempRestInfo D
   
   RETURN
END
GO

/****** Object:  UserDefinedFunction [dbo].[GetShipsFromStartPeriod]    Script Date: 25.07.2016 18:15:14 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

ALTER FUNCTION [dbo].[GetShipsFromStartPeriod]( 
    @PeriodDateBeg datetime,
	@PeriodDateEnd datetime,
	@OnDate datetime,

    @snapShotId int,
	@FilterStorageId varchar(500)=null,
    @FilterCenterId varchar(500)=null,
    @FilterRecieverPlanId varchar(500)=null,
    @FilterRecieverFactId varchar(500)=null,
    @FilterKeeperId varchar(500)=null,
    @FilterProducerId varchar(500)=null,

    @UseStorageFilter int=0,
    @UseCenterFilter int=0,
    @UseRecieverPlanFilter int=0,
    @UseRecieverFactFilter int=0,
    @UseKeeperFilter int=0,
    @UseProducerFilter int=0
)
RETURNS @RestInfoTable TABLE
   (
       [ShipForPeriod_Quantity]     decimal(18,2),
       [ShipForPeriod_Mass]         decimal(16,2),
       [ShipForPeriod_PE]           decimal(16,2),       
       [ShipForPeriod_PF]           decimal(16,2),          
       [ShipForPeriod_PCP]          decimal(16,2),          
       [ShipForPeriod_PCPC]         decimal(16,2), 
       [ShipForPeriod_FCP]          decimal(16,2),         
       [ShipForPeriod_FCPC]         decimal(16,2),
	   [ShipForPeriod_BP]           decimal(16,2)
   )
AS
BEGIN

   WITH tempRestInfo (Quantity,  Mass,    PE,    PF,   PCP,   PCPC,   FCP,   FCPC,  BP)
   AS
     (
		select  SUM(DC.QuantityRashod), 
		        SUM(DC.QuantityRashod*DC.Weight),
				SUM(DC.PE_Rashod),
				SUM(PF_Rashod),
				SUM(PCP_Rashod),
				SUM(PCPC_Rashod),
				SUM(FCP_Rashod),
				SUM(FCPC_Rashod),
				SUM(BP_Rashod)
		   FROM [dbo].[DocsSnapshot] DC
              WHERE (DC.id_snapshot=@snapShotId)
			    AND (DC.QuantityPrihod=0)
		        AND (DC.QuantityRashod!=0)
			    AND (convert(datetime, DC.RashodDocDate, 104) between @PeriodDateBeg and @OnDate)
                AND ((@UseStorageFilter=0)        OR ((@UseStorageFilter=1)       and(DC.Storage=@FilterStorageId)))
                AND ((@UseCenterFilter=0)         OR ((@UseCenterFilter=1)        and(DC.�enter=@FilterCenterId))) 
                AND ((@UseRecieverPlanFilter=0)   OR ((@UseRecieverPlanFilter=1)  and(DC.pRecieverPlan=@FilterRecieverPlanId)))
                AND ((@UseRecieverFactFilter=0)   OR ((@UseRecieverFactFilter=1)  and(DC.pRecieverFact=@FilterRecieverFactId)))
                AND ((@UseKeeperFilter=0)         OR ((@UseKeeperFilter=1)        and(DC.BalanceKeeper=@FilterKeeperId))) 
                AND ((@UseProducerFilter=0)       OR ((@UseProducerFilter=1)      and(DC.Producer=@FilterProducerId)))

     )

   INSERT @RestInfoTable
        SELECT SUM(D.Quantity), 
               SUM(D.Mass),
               SUM(D.PE),
               SUM(D.PF),
               SUM(D.PCP),
               SUM(D.PCPC),
               SUM(D.FCP),
               SUM(D.FCPC),
               SUM(D.BP)
          FROM tempRestInfo D
   
   RETURN
END
GO

/****** Object:  UserDefinedFunction [dbo].[GetShipsOnDate]    Script Date: 25.07.2016 18:16:10 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

ALTER FUNCTION [dbo].[GetShipsOnDate]( 
    @PeriodDateBeg datetime,
	@PeriodDateEnd datetime,
	@OnDate datetime,

    @snapShotId int,
	@FilterStorageId varchar(500)=null,
    @FilterCenterId varchar(500)=null,
    @FilterRecieverPlanId varchar(500)=null,
    @FilterRecieverFactId varchar(500)=null,
    @FilterKeeperId varchar(500)=null,
    @FilterProducerId varchar(500)=null,

    @UseStorageFilter int=0,
    @UseCenterFilter int=0,
    @UseRecieverPlanFilter int=0,
    @UseRecieverFactFilter int=0,
    @UseKeeperFilter int=0,
    @UseProducerFilter int=0
)
RETURNS @RestInfoTable TABLE
   (
       [ShipOnDate_Quantity]     decimal(18,2),
       [ShipOnDate_Mass]         decimal(16,2),
       [ShipOnDate_PE]           decimal(16,2),       
       [ShipOnDate_PF]           decimal(16,2),          
       [ShipOnDate_PCP]          decimal(16,2),          
       [ShipOnDate_PCPC]         decimal(16,2), 
       [ShipOnDate_FCP]          decimal(16,2),         
       [ShipOnDate_FCPC]         decimal(16,2),
	   [ShipOnDate_BP]           decimal(16,2)
   )
AS
BEGIN

   WITH tempRestInfo (Quantity,  Mass,    PE,    PF,   PCP,   PCPC,   FCP,   FCPC,  BP)
   AS
     (
		select  SUM(DC.QuantityRashod), 
		        SUM(DC.QuantityRashod*DC.Weight),
				SUM(DC.PE_Rashod),
				SUM(PF_Rashod),
				SUM(PCP_Rashod),
				SUM(PCPC_Rashod),
				SUM(FCP_Rashod),
				SUM(FCPC_Rashod),
				SUM(BP_Rashod)
		   FROM [dbo].[DocsSnapshot] DC
              WHERE (DC.id_snapshot=@snapShotId)
			    AND (DC.QuantityPrihod=0)
		        AND (DC.QuantityRashod!=0)
			    AND (convert(datetime, DC.RashodDocDate, 104) = @OnDate)
                AND ((@UseStorageFilter=0)        OR ((@UseStorageFilter=1)       and(DC.Storage=@FilterStorageId)))
                AND ((@UseCenterFilter=0)         OR ((@UseCenterFilter=1)        and(DC.�enter=@FilterCenterId))) 
                AND ((@UseRecieverPlanFilter=0)   OR ((@UseRecieverPlanFilter=1)  and(DC.pRecieverPlan=@FilterRecieverPlanId)))
                AND ((@UseRecieverFactFilter=0)   OR ((@UseRecieverFactFilter=1)  and(DC.pRecieverFact=@FilterRecieverFactId)))
                AND ((@UseKeeperFilter=0)         OR ((@UseKeeperFilter=1)        and(DC.BalanceKeeper=@FilterKeeperId))) 
                AND ((@UseProducerFilter=0)       OR ((@UseProducerFilter=1)      and(DC.Producer=@FilterProducerId)))

     )

   INSERT @RestInfoTable
        SELECT SUM(D.Quantity), 
               SUM(D.Mass),
               SUM(D.PE),
               SUM(D.PF),
               SUM(D.PCP),
               SUM(D.PCPC),
               SUM(D.FCP),
               SUM(D.FCPC),
               SUM(D.BP)
          FROM tempRestInfo D
   
   RETURN
END
GO

/****** Object:  StoredProcedure [dbo].[RestsSnapshotInsert]    Script Date: 25.07.2016 18:22:35 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
ALTER PROCEDURE [dbo].[RestsSnapshotInsert] 
@InnerPartyKey varchar(500),       @Producer varchar(500),       @Product varchar(100),
@Shifr varchar(50),                @Figure varchar(50),          @Measure varchar(50),
@Weight decimal(16,2),             @pType varchar(100),          @pGroup varchar(500),
@pRecieverPlan varchar(500),       @pRecieverFact varchar(500),  @RecieverGroupPlan varchar(100),
@InnerOrderNum varchar(50),        @OrderedBy varchar(500),      @OrderNum varchar(50),
@QuantityBefore decimal(18,2),     @PE_Before decimal(18,2),     @PF_Before decimal(18,2),
@PCP_Before decimal(18,2),         @PCPC_Before decimal(18,2),   @FCP_Before decimal(18,2),
@FCPC_Before decimal(18,2),        @BP_Before decimal(18,2),     @PE_After decimal(18,2),
@PF_After decimal(18,2),           @PCP_After decimal(18,2),     @PCPC_After decimal(18,2),
@FCP_After decimal(18,2),          @FCPC_After decimal(18,2),    @BP_After decimal(18,2),
@QuantityAfter decimal(18,2),      @Storage varchar(100),        @StorageCity varchar(50),
@StorageCountry varchar(10),       @�enter varchar(100),         @BalanceKeeper varchar(100),
@ReadyForSaleStatus varchar(50),   @ReserveStatus varchar(50),   @ProduceDate varchar(50),
@ReconcervationDate varchar(50),   @TermOnStorage int,           @PrihodDocType varchar(100),
@PrihodDocNum varchar(50),         @PrihodDocDate varchar(50),   @BalanceCurrency varchar(50),
@CurrencyIndexToUAH decimal(18,2), @id_snapshot INT
AS
BEGIN
  -- ��������� ������� �������� (��� �������)
	
	SET NOCOUNT ON;

	-- ������� ��������
    INSERT INTO [dbo].[RestsSnapshot]
           ([id_snapshot],     [InnerPartyKey],      [Producer],
            [Product],         [Shifr],              [Figure],
            [Measure],         [Weight],             [pType],
            [pGroup],          [pRecieverPlan],      [pRecieverFact],
            [RecieverGroupPlan], [InnerOrderNum],    [OrderedBy],
            [OrderNum],        [QuantityBefore],     [PE_Before],
            [PF_Before],       [PCP_Before],         [PCPC_Before],
            [FCP_Before],      [FCPC_Before],        [BP_Before],
            [PE_After],        [PF_After],           [PCP_After],
            [PCPC_After],      [FCP_After],          [FCPC_After],
            [BP_After],        [QuantityAfter],      [Storage],
            [StorageCity],     [StorageCountry],     [�enter],
            [BalanceKeeper],   [ReadyForSaleStatus], [ReserveStatus],
            [ProduceDate],     [ReconcervationDate], [TermOnStorage],
            [PrihodDocType],   [PrihodDocNum],       [PrihodDocDate],
            [BalanceCurrency], [CurrencyIndexToUAH])
     VALUES
           (@id_snapshot,       @InnerPartyKey,       @Producer,       
		    @Product,    		@Shifr ,              @Figure ,          
			@Measure,			@Weight,              @pType,          
			@pGroup,			@pRecieverPlan,       @pRecieverFact, 
			@RecieverGroupPlan, @InnerOrderNum,       @OrderedBy,      
			@OrderNum,			@QuantityBefore,      @PE_Before,	
			@PF_Before,			@PCP_Before,          @PCPC_Before,
			@FCP_Before,		@FCPC_Before,         @BP_Before,    
			@PE_After,  		@PF_After,            @PCP_After,     
			@PCPC_After,		@FCP_After,           @FCPC_After,   
			@BP_After, 			@QuantityAfter,       @Storage,     
			@StorageCity,		@StorageCountry,      @�enter,         
			@BalanceKeeper,		@ReadyForSaleStatus,  @ReserveStatus,   
			@ProduceDate,		@ReconcervationDate,  @TermOnStorage,           
			@PrihodDocType,		@PrihodDocNum,        @PrihodDocDate, 
			@BalanceCurrency,	@CurrencyIndexToUAH)
END
GO
/****** Object:  StoredProcedure [dbo].[DocsSnapshotInsert]    Script Date: 04.07.2016 18:13:09 ******/
SET ANSI_NULLS ON
GO
