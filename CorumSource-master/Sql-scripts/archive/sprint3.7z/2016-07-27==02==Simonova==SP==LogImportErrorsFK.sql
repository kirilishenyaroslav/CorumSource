
ALTER TABLE [dbo].[LogImportErrors]  WITH NOCHECK ADD  CONSTRAINT [FK_LogImportErrors_LogisticSnapshots] FOREIGN KEY([idSnapshot])
REFERENCES [dbo].[LogisticSnapshots] ([id_spanshot])
ON DELETE CASCADE
GO

ALTER TABLE [dbo].[LogImportErrors] CHECK CONSTRAINT [FK_LogImportErrors_LogisticSnapshots]
GO

