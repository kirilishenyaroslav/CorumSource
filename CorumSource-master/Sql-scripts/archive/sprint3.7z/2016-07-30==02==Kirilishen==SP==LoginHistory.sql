
/****** Object:  Table [dbo].[LoginHistory]    Script Date: 7/30/2016 07:46:55 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

CREATE TABLE [dbo].[LoginHistory](
	[RowId] [bigint] IDENTITY(1,1) NOT NULL,
	[userId] [nvarchar](128) NOT NULL,
	[Datetime] [datetime2](7) NOT NULL,
	[IP] [varchar](20) NOT NULL,
	[userAgent] [varchar](max) NOT NULL,
 CONSTRAINT [PK_LoginHistory] PRIMARY KEY CLUSTERED 
(
	[RowId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO

ALTER TABLE [dbo].[LoginHistory] ADD  CONSTRAINT [DF_LoginHistory_Datetime]  DEFAULT (getdate()) FOR [Datetime]
GO

ALTER TABLE [dbo].[LoginHistory]  WITH CHECK ADD  CONSTRAINT [FK_LoginHistory_AspNetUsers1] FOREIGN KEY([userId])
REFERENCES [dbo].[AspNetUsers] ([Id])
ON DELETE CASCADE
GO

ALTER TABLE [dbo].[LoginHistory] CHECK CONSTRAINT [FK_LoginHistory_AspNetUsers1]
GO


