alter table [dbo].[AspNetUsers]
add PostName nvarchar(256) null;

GO

alter table [dbo].[AspNetUsers]
add ContactPhone nvarchar(256) null;

GO