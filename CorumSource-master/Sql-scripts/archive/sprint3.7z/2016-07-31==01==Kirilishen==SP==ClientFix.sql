alter table [dbo].[OrderClients]
add ClientBalanceKeeperId int null;

GO

alter table [dbo].[OrderClients]
add ClientCFOId int null;

GO