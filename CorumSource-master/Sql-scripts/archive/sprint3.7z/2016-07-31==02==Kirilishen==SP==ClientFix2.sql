

ALTER TABLE [dbo].[OrderClients]  WITH CHECK ADD  CONSTRAINT [FK_OrderClients_BalanceKeepers] FOREIGN KEY([ClientBalanceKeeperId])
REFERENCES [dbo].[BalanceKeepers] ([Id])
GO

ALTER TABLE [dbo].[OrderClients] CHECK CONSTRAINT [FK_OrderClients_BalanceKeepers]
GO


ALTER TABLE [dbo].[OrderClients]  WITH CHECK ADD  CONSTRAINT [FK_OrderClients_Centers] FOREIGN KEY([ClientCFOId])
REFERENCES [dbo].[Centers] ([Id])
GO

ALTER TABLE [dbo].[OrderClients] CHECK CONSTRAINT [FK_OrderClients_Centers]
GO
