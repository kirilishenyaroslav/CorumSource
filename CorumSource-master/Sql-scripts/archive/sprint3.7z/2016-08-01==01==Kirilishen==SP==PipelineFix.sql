alter table [dbo].[OrderPipelineSteps]
add StartDateForClient bit null Default(0);


go

alter table [dbo].[OrderPipelineSteps]
add StartDateForExecuter bit null Default(0);

GO

alter table [dbo].[OrderPipelineSteps]
add OrderTypeId int null;