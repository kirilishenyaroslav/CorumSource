

ALTER TABLE [dbo].[OrderPipelineSteps]  WITH CHECK ADD  CONSTRAINT [FK_OrderPipelineSteps_OrderTypesBase] FOREIGN KEY([OrderTypeId])
REFERENCES [dbo].[OrderTypesBase] ([Id])
GO

ALTER TABLE [dbo].[OrderPipelineSteps] CHECK CONSTRAINT [FK_OrderPipelineSteps_OrderTypesBase]
GO


