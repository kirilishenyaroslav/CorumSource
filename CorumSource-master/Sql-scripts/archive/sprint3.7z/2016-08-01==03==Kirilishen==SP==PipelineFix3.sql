

/****** Object:  Index [UniquePipelineStepsIndex]    Script Date: 8/1/2016 09:38:48 PM ******/
DROP INDEX [UniquePipelineStepsIndex] ON [dbo].[OrderPipelineSteps]
GO

/****** Object:  Index [NonClusteredIndex-20160801-213923]    Script Date: 8/1/2016 09:39:39 PM ******/
CREATE UNIQUE NONCLUSTERED INDEX [NonClusteredIndex-20160801-213923] ON [dbo].[OrderPipelineSteps]
(
	[FromStatus] ASC,
	[ToStatus] ASC,
	[OrderTypeId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO

