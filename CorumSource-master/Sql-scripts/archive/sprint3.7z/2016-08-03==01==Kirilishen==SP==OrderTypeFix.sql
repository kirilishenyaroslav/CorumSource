alter table [dbo].[OrderTypesBase]
add UserRoleIdForClientData nvarchar(128) null;

go

alter table [dbo].[OrderTypesBase]
add UserRoleIdForExecuterData nvarchar(128) null;

go

alter table [dbo].[OrderTypesBase]
add IsActive bit not null Default(0);

GO