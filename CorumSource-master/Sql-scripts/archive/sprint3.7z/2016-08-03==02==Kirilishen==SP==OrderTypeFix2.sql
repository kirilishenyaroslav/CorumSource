
ALTER TABLE [dbo].[OrderTypesBase]  WITH CHECK ADD  CONSTRAINT [FK_OrderTypesBase_AspNetRoles] FOREIGN KEY([UserRoleIdForClientData])
REFERENCES [dbo].[AspNetRoles] ([Id])
GO

ALTER TABLE [dbo].[OrderTypesBase] CHECK CONSTRAINT [FK_OrderTypesBase_AspNetRoles]

GO

ALTER TABLE [dbo].[OrderTypesBase]  WITH CHECK ADD  CONSTRAINT [FK_OrderTypesBase_AspNetRoles1] FOREIGN KEY([UserRoleIdForExecuterData])
REFERENCES [dbo].[AspNetRoles] ([Id])
GO

ALTER TABLE [dbo].[OrderTypesBase] CHECK CONSTRAINT [FK_OrderTypesBase_AspNetRoles1]
GO

