SET IDENTITY_INSERT [dbo].[MenuStructure] ON 

GO
INSERT [dbo].[MenuStructure] ([Id], [menuName], [menuId], [parentId]) VALUES (20, N'������ �����', N'20', 1)
GO


SET IDENTITY_INSERT [dbo].[MenuStructure] OFF
GO
