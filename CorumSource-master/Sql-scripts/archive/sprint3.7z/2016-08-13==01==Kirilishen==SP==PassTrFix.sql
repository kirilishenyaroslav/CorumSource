alter table [dbo].[OrdersPassengerTransport]
add NeedReturn bit not null Default(0);

GO

alter table [dbo].[OrdersPassengerTransport]
add ReturnStartDateTimeOfTrip  datetime2(7) null; 

GO

alter table [dbo].[OrdersPassengerTransport]
add ReturnFinishDateTimeOfTrip  datetime2(7) null; 

GO

alter table [dbo].[OrdersPassengerTransport]
add ReturnWaitingTime time null; 

GO