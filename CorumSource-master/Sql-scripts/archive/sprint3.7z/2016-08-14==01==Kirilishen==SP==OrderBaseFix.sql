alter table [dbo].[OrdersBase]
add PriotityType int not null Default(0);

GO

alter table [dbo].[OrdersBase]
add OrderServiceDateTime datetime2(7) null;

GO
