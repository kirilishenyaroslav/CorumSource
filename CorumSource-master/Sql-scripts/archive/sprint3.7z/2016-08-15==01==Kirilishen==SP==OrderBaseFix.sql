alter table [dbo].[OrdersPassengerTransport]
add PassInfo varchar(max) null;

go