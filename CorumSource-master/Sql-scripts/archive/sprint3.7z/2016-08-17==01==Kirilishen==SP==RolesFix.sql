alter table [dbo].[AspNetRoles]
add RoleDescription varchar(500) null;

GO