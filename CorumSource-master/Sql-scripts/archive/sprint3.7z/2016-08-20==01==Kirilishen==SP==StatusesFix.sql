﻿ALTER TABLE OrderStatuses
  ADD IconFile VARCHAR(25) NULL;
GO

ALTER TABLE OrderStatuses
  ADD IconDescription VARCHAR(500) NULL;

GO;