alter table [dbo].[OrdersPassengerTransport]
add [OrgFrom] varchar(500) null;

GO

alter table [dbo].[OrdersPassengerTransport]
add [OrgTo] varchar(500) null;

GO