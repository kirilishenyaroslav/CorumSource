delete from [dbo].[MenuStructure]
where [Id] = 20
go