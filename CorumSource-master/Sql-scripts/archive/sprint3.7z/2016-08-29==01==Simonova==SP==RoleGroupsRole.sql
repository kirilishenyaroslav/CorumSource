alter table [dbo].[RoleGroupsRole]
add RoleGroupsDate DateTime null;

GO