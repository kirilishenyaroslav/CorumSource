alter table [dbo].[OrdersBase]
add OrderExecuter nvarchar(128) null;

GO

ALTER TABLE [dbo].[OrdersBase]  WITH CHECK ADD  CONSTRAINT [FK_OrdersBase_AspNetUsers1] FOREIGN KEY([OrderExecuter])
REFERENCES [dbo].[AspNetUsers] ([Id])
GO

ALTER TABLE [dbo].[OrdersBase] CHECK CONSTRAINT [FK_OrdersBase_AspNetUsers1]
GO
