alter table [dbo].[OrdersBase]
add PayerId int null;

GO

alter table [dbo].[OrdersBase]
add ProjectNum varchar(50) null;

GO
