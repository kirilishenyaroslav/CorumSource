

ALTER TABLE [dbo].[OrdersBase]  WITH CHECK ADD  CONSTRAINT [FK_OrdersBase_BalanceKeepers] FOREIGN KEY([PayerId])
REFERENCES [dbo].[BalanceKeepers] ([Id])
GO

ALTER TABLE [dbo].[OrdersBase] CHECK CONSTRAINT [FK_OrdersBase_BalanceKeepers]
GO


