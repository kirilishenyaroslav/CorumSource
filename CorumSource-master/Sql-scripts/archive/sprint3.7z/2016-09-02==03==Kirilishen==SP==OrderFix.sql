

ALTER TABLE [dbo].[OrderClients] DROP CONSTRAINT [FK_OrderClients_BalanceKeepers]
GO

alter table [dbo].[OrderClients]
drop column [ClientBalanceKeeperId];

GO