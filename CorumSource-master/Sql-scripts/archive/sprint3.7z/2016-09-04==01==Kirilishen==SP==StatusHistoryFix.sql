﻿ ALTER TABLE [dbo].[OrderStatusHistory]
      	ADD StatusChangeComment VARCHAR(500) NULL
      GO
      