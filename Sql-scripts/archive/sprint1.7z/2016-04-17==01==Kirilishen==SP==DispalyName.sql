alter table AspNetUsers
add DisplayName nvarchar(256) null;

GO

IF OBJECT_ID('AspNetUsers_AfterInsert_TRG') IS NOT NULL
DROP TRIGGER AspNetUsers_AfterInsert_TRG
GO

CREATE TRIGGER AspNetUsers_AfterInsert_TRG 
  ON [dbo].[AspNetUsers] 
AFTER INSERT
AS
  declare @DisplayName nvarchar(256);
  declare @Id nvarchar(128); 

  SELECT TOP 1 @DisplayName = I.DisplayName FROM inserted AS I;
  SELECT TOP 1 @Id =  I.Id FROM inserted AS I;

  if (@DisplayName is null)
  begin
      UPDATE [dbo].[AspNetUsers]
         SET [dbo].[AspNetUsers].DisplayName = [dbo].[AspNetUsers].UserName
       WHERE [dbo].[AspNetUsers].Id = @Id ; 
  end   
  
  GO
  
  insert into AspNetRoles (Id, Name)
  values ('1000','administrator');
  insert into AspNetRoles (Id, Name)
  values ('1001','role1');
  insert into AspNetRoles (Id, Name)
  values ('1002','role2');
  insert into AspNetRoles (Id, Name)
  values ('1003','role3');
  insert into AspNetRoles (Id, Name)
  values ('1004','role4');
  insert into AspNetRoles (Id, Name)
  values ('1005','role5');
  
  GO
  
  update AspNetUsers
  set AspNetUsers.DisplayName='SupportAccount';
  
  GO
  
  insert into AspNetUserRoles (UserId, RoleId)
  values ('dcd20189-825d-4abd-822a-6905034fc0ef','1000');
  
  GO
   