USE [Corum]
GO

/****** Object:  Table [dbo].[LogisticSnapshots]    Script Date: 23.04.2016 18:48:59 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[LogisticSnapshots](
	[id_spanshot] [int] IDENTITY(1,1) NOT NULL,
	[shapshot_data] [date] NOT NULL,
	[isRestsLoaded] [bit] NULL,
	[isDocsLoaded] [bit] NULL,
 CONSTRAINT [PK_LogisticSnapshots] PRIMARY KEY CLUSTERED 
(
	[id_spanshot] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO


GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[RestsSnapshot](
	[idrow] [bigint] IDENTITY(1,1) NOT NULL,
	[id_snapshot] [int] NOT NULL,
	[storage] [nvarchar](256) NOT NULL,
	[shifr] [nvarchar](50) NOT NULL,
	[figure] [nvarchar](50) NOT NULL,
	[product] [nvarchar](500) NOT NULL,
	[orderNum] [nvarchar](50) NULL,
	[measure] [nvarchar](50) NOT NULL,
	[p_reciever] [nvarchar](500) NOT NULL,
	[quantityPlan] [decimal](16, 2) NOT NULL,
	[quantityFact] [decimal](16, 2) NOT NULL,
	[storage_location] [nvarchar](500) NULL,
	[pGroup] [nvarchar](500) NULL,
	[pType] [nvarchar](500) NULL,
	[recieverGroup] [nvarchar](500) NULL,
	[recieverCountry] [nvarchar](50) NULL,
	[restBefore] [decimal](16, 2) NOT NULL,
	[restAfter] [decimal](16, 2) NOT NULL,
	[sumBefore] [decimal](16, 2) NOT NULL,
	[sumAfter] [decimal](16, 2) NOT NULL,
	[term_in_storage] [int] NOT NULL,
	[CFO] [decimal](16, 2) NOT NULL,
	[PE] [decimal](16, 2) NOT NULL,
	[PF] [decimal](16, 2) NOT NULL,
	[PCP] [decimal](16, 2) NOT NULL,
	[PCPC] [decimal](16, 2) NOT NULL,
	[PCFP] [decimal](16, 2) NOT NULL,
	[BP] [decimal](16, 2) NOT NULL,
 CONSTRAINT [PK_RestsSnapshot] PRIMARY KEY CLUSTERED 
(
	[idrow] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

ALTER TABLE [dbo].[RestsSnapshot] ADD  DEFAULT ((0)) FOR [quantityPlan]
GO

ALTER TABLE [dbo].[RestsSnapshot] ADD  DEFAULT ((0)) FOR [quantityFact]
GO

ALTER TABLE [dbo].[RestsSnapshot] ADD  DEFAULT ((0)) FOR [restBefore]
GO

ALTER TABLE [dbo].[RestsSnapshot] ADD  DEFAULT ((0)) FOR [restAfter]
GO

ALTER TABLE [dbo].[RestsSnapshot] ADD  DEFAULT ((0)) FOR [sumBefore]
GO

ALTER TABLE [dbo].[RestsSnapshot] ADD  DEFAULT ((0)) FOR [sumAfter]
GO

ALTER TABLE [dbo].[RestsSnapshot] ADD  DEFAULT ((0)) FOR [term_in_storage]
GO

ALTER TABLE [dbo].[RestsSnapshot] ADD  DEFAULT ((0)) FOR [CFO]
GO

ALTER TABLE [dbo].[RestsSnapshot] ADD  DEFAULT ((0)) FOR [PE]
GO

ALTER TABLE [dbo].[RestsSnapshot] ADD  DEFAULT ((0)) FOR [PF]
GO

ALTER TABLE [dbo].[RestsSnapshot] ADD  DEFAULT ((0)) FOR [PCP]
GO

ALTER TABLE [dbo].[RestsSnapshot] ADD  DEFAULT ((0)) FOR [PCPC]
GO

ALTER TABLE [dbo].[RestsSnapshot] ADD  DEFAULT ((0)) FOR [PCFP]
GO

ALTER TABLE [dbo].[RestsSnapshot] ADD  DEFAULT ((0)) FOR [BP]
GO

ALTER TABLE [dbo].[RestsSnapshot]  WITH CHECK ADD  CONSTRAINT [FK_RestsSnapshot_LogisticSnapshots] FOREIGN KEY([id_snapshot])
REFERENCES [dbo].[LogisticSnapshots] ([id_spanshot])
GO

ALTER TABLE [dbo].[RestsSnapshot] CHECK CONSTRAINT [FK_RestsSnapshot_LogisticSnapshots]
GO