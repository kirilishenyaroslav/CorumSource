﻿alter table [dbo].[RestsSnapshot]
add Center varchar(500) null;

GO

DECLARE @ObjectName NVARCHAR(100)
SELECT @ObjectName = OBJECT_NAME([default_object_id]) FROM SYS.COLUMNS
WHERE [object_id] = OBJECT_ID('[dbo].[RestsSnapshot]') AND [name] = 'CFO';
EXEC('ALTER TABLE [dbo].[RestsSnapshot] DROP CONSTRAINT ' + @ObjectName)

GO

alter table [dbo].[RestsSnapshot]
drop column CFO;

GO

update [dbo].[RestsSnapshot]
   set [dbo].[RestsSnapshot].Center='КОРУМ Украина';