alter table [dbo].[RestsSnapshot]
add FCP  decimal(16,2) not null Default(0);

GO

alter table [dbo].[RestsSnapshot]
add FCPC  decimal(16,2) not null Default(0);

GO

DECLARE @ObjectName NVARCHAR(100)
SELECT @ObjectName = OBJECT_NAME([default_object_id]) FROM SYS.COLUMNS
WHERE [object_id] = OBJECT_ID('[dbo].[RestsSnapshot]') AND [name] = 'PCFP';
EXEC('ALTER TABLE [dbo].[RestsSnapshot] DROP CONSTRAINT ' + @ObjectName)

GO

alter table [dbo].[RestsSnapshot]
drop column PCFP;
