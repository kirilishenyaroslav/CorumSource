﻿Alter table RestsSnapshot 
add p_reciever_plan nvarchar(500);

GO

Alter table RestsSnapshot 
add p_reciever_fact nvarchar(500);

GO

Alter table RestsSnapshot 
add balance_keeper nvarchar(500);

GO

Alter table RestsSnapshot 
add producer nvarchar(500);

GO

update [dbo].[RestsSnapshot]
   set [dbo].[RestsSnapshot].p_reciever_plan = [dbo].[RestsSnapshot].p_reciever,
       [dbo].[RestsSnapshot].p_reciever_fact = [dbo].[RestsSnapshot].p_reciever;

GO

Alter table RestsSnapshot 
drop column p_reciever;

GO

Alter table RestsSnapshot 
add liquid_status nvarchar(50);

GO

Alter table RestsSnapshot 
add reserve_status nvarchar(50);

GO

update [dbo].[RestsSnapshot]
   set [dbo].[RestsSnapshot].liquid_status = 'Ликвидный';
       
GO

update [dbo].[RestsSnapshot]
   set [dbo].[RestsSnapshot].producer = 'Завод 1';

GO

update [dbo].[RestsSnapshot]
   set [dbo].[RestsSnapshot].balance_keeper = 'Балансодержатель 1';

GO

Alter table RestsSnapshot 
add DocType nvarchar(50);

GO

Alter table RestsSnapshot 
add DocNumber nvarchar(50);

GO

Alter table RestsSnapshot 
add DocDate datetime;

GO

Alter table RestsSnapshot 
add OrderDate datetime;
	
GO

Alter table RestsSnapshot 
add Orderer nvarchar(500);

GO

Alter table RestsSnapshot 
add produce_date datetime;

GO

Alter table RestsSnapshot 
add reconcervation_date datetime;
	
GO