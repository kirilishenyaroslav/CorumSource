USE [Corum]
GO


/****** Object:  Table [dbo].[RestsSnapshot]    Script Date: 05/12/2016 21:09:35 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[RestsSnapshot]') AND type in (N'U'))
DROP TABLE [dbo].[RestsSnapshot]
GO
/****** Object:  Table [dbo].[RestsSnapshot]    Script Date: 05/12/2016 21:09:03 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

CREATE TABLE [dbo].[RestsSnapshot](
	[idrow] [bigint] IDENTITY(1,1) NOT NULL,
	[id_snapshot] [int] NOT NULL,
	[InnerPartyKey] [varchar](500) NULL,
	[Producer] [varchar](500) NULL,
	[Product] [varchar](100) NULL,
	[Shifr] [varchar](50) NULL,
	[Figure] [varchar](50) NULL,
	[Measure] [varchar](50) NULL,
	[Weight] [decimal](16, 2) NULL,
	[pType] [varchar](100) NULL,
	[pGroup] [varchar](500) NULL,
	[pRecieverPlan] [varchar](500) NULL,
	[pRecieverFact] [varchar](500) NULL,
	[RecieverGroup] [varchar](100) NULL,
	[InnerOrderNum] [varchar](50) NULL,
	[OrderedBy] [varchar](500) NULL,
	[OrderNum] [varchar](50) NULL,
	[QuantityBefore] [int] NULL,
	[PE_Before] [decimal](18, 2) NULL,
	[PF_Before] [decimal](18, 2) NULL,
	[PCP_Before] [decimal](18, 2) NULL,
	[PCPC_Before] [decimal](18, 2) NULL,
	[FCP_Before] [decimal](18, 2) NULL,
	[FCPC_Before] [decimal](18, 2) NULL,
	[BP_Before] [decimal](18, 2) NULL,
	[PE_After] [decimal](18, 2) NULL,
	[PF_After] [decimal](18, 2) NULL,
	[PCP_After] [decimal](18, 2) NULL,
	[PCPC_After] [decimal](18, 2) NULL,
	[FCP_After] [decimal](18, 2) NULL,
	[FCPC_After] [decimal](18, 2) NULL,
	[BP_After] [decimal](18, 2) NULL,
	[QuantityAfter] [int] NULL,
	[Storage] [varchar](100) NULL,
	[StorageCity] [varchar](50) NULL,
	[StorageCountry] [varchar](10) NULL,
	[�enter] [varchar](100) NULL,
	[BalanceKeeper] [varchar](100) NULL,
	[ReadyForSaleStatus] [varchar](50) NULL,
	[ReserveStatus] [varchar](50) NULL,
	[ProduceDate] [varchar](50) NULL,
	[ReconcervationDate] [varchar](50) NULL,
	[TermOnStorage] [int] NULL,
	[CreateByDoc] [varchar](100) NULL,
	[CreateByDocNum] [varchar](50) NULL,
	[CreateByDocDate] [varchar](50) NULL,
	[BalanceCurrency] [varchar](50) NULL,
	[CurrencyIndexToUAH] [decimal](18, 2) NULL,
 CONSTRAINT [PK_RestsSnapshot] PRIMARY KEY CLUSTERED 
(
	[idrow] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO


                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             