USE [Corum]
GO

/****** Object:  Table [dbo].[RestsSnapshot]    Script Date: 05/12/2016 21:09:03 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

CREATE TABLE [dbo].[DocsSnapshot](
	[idrow] [bigint] IDENTITY(1,1) NOT NULL,
	[id_snapshot] [int] NOT NULL,
	[InnerPartyKey] [varchar](500) NULL,
	[Producer] [varchar](500) NULL,
	[Product] [varchar](100) NULL,
	[Shifr] [varchar](50) NULL,
	[Figure] [varchar](50) NULL,
	[Measure] [varchar](50) NULL,
	[Weight] [decimal](16, 2) NULL,
	[pType] [varchar](100) NULL,
	[pGroup] [varchar](500) NULL,
	[pRecieverPlan] [varchar](500) NULL,
	[pRecieverFact] [varchar](500) NULL,
	[RecieverGroup] [varchar](100) NULL,
	[InnerOrderNum] [varchar](50) NULL,
	[OrderedBy] [varchar](500) NULL,
	[OrderNum] [varchar](50) NULL,
	[QuantityPrihod] [int] NULL,
	[PE_Prihod] [decimal](18, 2) NULL,
	[PF_Prihod] [decimal](18, 2) NULL,
	[PCP_Prihod] [decimal](18, 2) NULL,
	[PCPC_Prihod] [decimal](18, 2) NULL,
	[FCP_Prihod] [decimal](18, 2) NULL,
	[FCPC_Prihod] [decimal](18, 2) NULL,
	[BP_Prihod] [decimal](18, 2) NULL,
	[PE_Rashod] [decimal](18, 2) NULL,
	[PF_Rashod] [decimal](18, 2) NULL,
	[PCP_Rashod] [decimal](18, 2) NULL,
	[PCPC_Rashod] [decimal](18, 2) NULL,
	[FCP_Rashod] [decimal](18, 2) NULL,
	[FCPC_Rashod] [decimal](18, 2) NULL,
	[BP_Rashod] [decimal](18, 2) NULL,
	[QuantityRashod] [int] NULL,
	[Storage] [varchar](100) NULL,
	[StorageCity] [varchar](50) NULL,
	[StorageCountry] [varchar](10) NULL,
	[�enter] [varchar](100) NULL,
	[BalanceKeeper] [varchar](100) NULL,
	[ReadyForSaleStatus] [varchar](50) NULL,
	[ReserveStatus] [varchar](50) NULL,
	[ProduceDate] [varchar](50) NULL,
	[ReconcervationDate] [varchar](50) NULL,
	[TermOnStorage] [int] NULL,
	[PrihodDocType] [varchar](100) NULL,
	[PrihodDocNum] [varchar](50) NULL,
	[PrihodDocDate] [varchar](50) NULL,
	[RashodDocType] [varchar](100) NULL,
	[RashodDocNum] [varchar](50) NULL,
	[RashodDocDate] [varchar](50) NULL,
	[BalanceCurrency] [varchar](50) NULL,
	[CurrencyIndexToUAH] [decimal](18, 2) NULL,
 CONSTRAINT [PK_DocsSnapshot] PRIMARY KEY CLUSTERED 
(
	[idrow] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO



ALTER TABLE [dbo].[DocsSnapshot]  WITH CHECK ADD  CONSTRAINT [FK_DocsSnapshot_LogisticSnapshots] FOREIGN KEY([id_snapshot])
REFERENCES [dbo].[LogisticSnapshots] ([id_spanshot])
GO

ALTER TABLE [dbo].[DocsSnapshot] CHECK CONSTRAINT [FK_DocsSnapshot_LogisticSnapshots]
GO

