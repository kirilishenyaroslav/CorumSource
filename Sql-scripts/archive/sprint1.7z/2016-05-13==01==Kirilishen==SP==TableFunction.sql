
/****** Object:  UserDefinedFunction [dbo].[GetDocsSummaryByInnerKey]    Script Date: 05/13/2016 09:00:08 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE FUNCTION [dbo].[GetDocsSummaryByInnerKey]( 
    @snapShotId int,
    @innerPartyKey varchar(500),
    @isPrihodDocs int 
)
RETURNS @DocsSummaryTable TABLE
   (
       Quantity     int,
       Mass         decimal(16,2),
       PE           decimal(16,2),       
       PF           decimal(16,2),          
       PCP          decimal(16,2),          
       PCPC         decimal(16,2), 
       FCP          decimal(16,2),         
       FCPC         decimal(16,2),
	   BP           decimal(16,2)
   )
AS
BEGIN

   IF (@isPrihodDocs=1)
   BEGIN

   INSERT @DocsSummaryTable
        SELECT SUM(D.QuantityPrihod), 
               SUM(D.Weight*D.QuantityPrihod),
               SUM(D.PE_Prihod),
               SUM(D.PF_Prihod),
               SUM(D.PCP_Prihod),
               SUM(D.PCPC_Prihod),
               SUM(D.FCP_Prihod),
               SUM(D.FCPC_Prihod),
               SUM(D.BP_Prihod)
          FROM [dbo].[DocsSnapshot] D
         where D.id_snapshot = @snapShotId
           and D.InnerPartyKey = @innerPartyKey
           
   END
   ELSE BEGIN
   INSERT @DocsSummaryTable
        SELECT SUM(D.QuantityRashod), 
               SUM(D.Weight*D.QuantityRashod),
               SUM(D.PE_Rashod),
               SUM(D.PF_Rashod),
               SUM(D.PCP_Rashod),
               SUM(D.PCPC_Rashod),
               SUM(D.FCP_Rashod),
               SUM(D.FCPC_Rashod),
               SUM(D.BP_Rashod)
          FROM [dbo].[DocsSnapshot] D
         where D.id_snapshot = @snapShotId
           and D.InnerPartyKey = @innerPartyKey
   END
   
   
      
           
   RETURN
END
GO


