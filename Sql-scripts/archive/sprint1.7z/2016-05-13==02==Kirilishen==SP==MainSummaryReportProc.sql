

/****** Object:  StoredProcedure [dbo].[GetSummaryDataBySnapshot]    Script Date: 05/13/2016 09:00:55 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


CREATE PROCEDURE [dbo].[GetSummaryDataBySnapshot] 
	@snapShotId int 
AS
BEGIN
	 SELECT R.[idrow],               R.[id_snapshot],       R.[InnerPartyKey],         R.[Producer],            R.[Product],            R.[Shifr],
	        R.[Figure],              R.[Measure],           R.[Weight],                R.[pType],               R.[pGroup],             R.[pRecieverPlan],
	        R.[pRecieverFact],       R.[RecieverGroup],     R.[InnerOrderNum],         R.[OrderedBy],           R.[OrderNum],           R.[QuantityBefore],
	        R.[PE_Before],           R.[PF_Before],         R.[PCP_Before],            R.[PCPC_Before],         R.[FCP_Before],         R.[FCPC_Before],
	        R.[BP_Before],           R.[PE_After],          R.[PF_After],              R.[PCP_After],           R.[PCPC_After],         R.[FCP_After],
	        R.[FCPC_After],          R.[BP_After],          R.[QuantityAfter],         R.[Storage],             R.[StorageCity],        R.[StorageCountry],
	        R.[�enter],              R.[BalanceKeeper],     R.[ReadyForSaleStatus],    R.[ReserveStatus],       R.[ProduceDate],        R.[ReconcervationDate],
	        R.[TermOnStorage],       R.[CreateByDoc],       R.[CreateByDocNum],        R.[CreateByDocDate],     R.[BalanceCurrency],    R.[CurrencyIndexToUAH],
	        
	        coalesce(PR.[Quantity],0) AS QuantityPrihod, 
	        coalesce(PR.[Mass],0)     AS MassPrihod,  
	        coalesce(PR.[PE],0)       AS PE_Prihod,
	        coalesce(PR.[PF],0)       AS PF_Prihod,
	        coalesce(PR.[PCP],0)      AS PCP_Prihod,
	        coalesce(PR.[PCPC],0)     AS PCPC_Prihod,
            coalesce(PR.[FCP],0)      AS FCP_Prihod,          
            coalesce(PR.[FCPC],0)     AS FCPC_Prihod,
            coalesce(PR.[BP],0)       AS BP_Prihod,
            
            coalesce(RX.[Quantity],0) AS QuantityRashod,
            coalesce(RX.[Mass],0)     AS MassRashod,
            coalesce(RX.[PE],0)       AS PE_Rashod,
            coalesce(RX.[PF],0)       AS PF_Rashod,
            coalesce(RX.[PCP],0)      AS PCP_Rashod,
            coalesce(RX.[PCPC],0)     AS PCPC_Rashod,
            coalesce(RX.[FCP],0)      AS FCP_Rashod,
            coalesce(RX.[FCPC],0)     AS FCPC_Rashod,
            coalesce(RX.[BP],0)       AS BP_Rashod
            
       FROM [Corum].[dbo].[RestsSnapshot] R
      OUTER APPLY [dbo].GetDocsSummaryByInnerKey(@snapShotId, R.InnerPartyKey, 1) PR
      OUTER APPLY [dbo].GetDocsSummaryByInnerKey(@snapShotId, R.InnerPartyKey, 0) RX
      where R.id_snapshot=@snapShotId
END

GO


