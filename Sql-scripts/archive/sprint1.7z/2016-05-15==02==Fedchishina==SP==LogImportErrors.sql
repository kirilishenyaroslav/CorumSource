
/****** Object:  Table [dbo].[LogImportErrors]    Script Date: 15.05.2016 20:34:25 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[LogImportErrors](
	[IsRests] [bit] NULL,
	[NumRow] [int] NULL,
	[ColumnName] [nvarchar](500) NULL,
	[CommentError] [nvarchar](max) NULL,
	[guidSession] [nvarchar](36) NULL,
	[DateWriteLog] [datetime] NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

GO


