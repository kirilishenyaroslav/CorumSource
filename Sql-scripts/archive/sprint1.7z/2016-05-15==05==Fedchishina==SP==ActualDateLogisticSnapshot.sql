

/****** Object:  Table [dbo].[LogisticSnapshots]    Script Date: 15.05.2016 20:39:56 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

ALTER TABLE dbo.LogisticSnapshots ADD ActualDateBeg date NULL ;
GO

ALTER TABLE dbo.LogisticSnapshots ADD ActualDateEnd date NULL ;
GO



