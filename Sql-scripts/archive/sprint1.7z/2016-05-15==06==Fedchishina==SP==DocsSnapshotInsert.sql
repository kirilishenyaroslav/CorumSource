
/****** Object:  StoredProcedure [dbo].[DocsSnapshotInsert]    Script Date: 15.05.2016 20:42:14 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-- Batch submitted through debugger: SQLQuery40.sql|7|0|C:\Users\LASTOC~1\AppData\Local\Temp\~vs69A4.sql
-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[DocsSnapshotInsert] 
@ActualDateBeg varchar(50),        @ActualDateEnd varchar(50),
@InnerPartyKey varchar(500),       @Producer varchar(500),       @Product varchar(100),
@Shifr varchar(50),                @Figure varchar(50),          @Measure varchar(50),
@Weight decimal(16,2),             @pType varchar(100),          @pGroup varchar(500),
@pRecieverPlan varchar(500),       @pRecieverFact varchar(500),  @RecieverGroup varchar(100),
@InnerOrderNum varchar(50),        @OrderedBy varchar(500),      @OrderNum varchar(50),
@QuantityPrihod int,               @PE_Prihod decimal(18,2),     @PF_Prihod decimal(18,2),
@PCP_Prihod decimal(18,2),         @PCPC_Prihod decimal(18,2),   @FCP_Prihod decimal(18,2),
@FCPC_Prihod decimal(18,2),        @BP_Prihod decimal(18,2),     @PE_Rashod decimal(18,2),
@PF_Rashod decimal(18,2),          @PCP_Rashod decimal(18,2),    @PCPC_Rashod decimal(18,2),
@FCP_Rashod decimal(18,2),         @FCPC_Rashod decimal(18,2),   @BP_Rashod decimal(18,2),
@QuantityRashod int,               @Storage varchar(100),        @StorageCity varchar(50),
@StorageCountry varchar(10),       @�enter varchar(100),         @BalanceKeeper varchar(100),
@ReadyForSaleStatus varchar(50),   @ReserveStatus varchar(50),   @ProduceDate varchar(50),
@ReconcervationDate varchar(50),   @TermOnStorage int,           @PrihodDocType varchar(100),
@PrihodDocNum varchar(50),         @PrihodDocDate varchar(50),   @RashodDocType varchar(100),
@RashodDocNum varchar(50),         @RashodDocDate varchar(50),   @BalanceCurrency varchar(50),
@CurrencyIndexToUAH decimal(18,2)
AS
BEGIN
  -- ��������� ������� ���������� (��� �������)
	SET NOCOUNT ON;
	DECLARE @id_snapshot INT;
	set @id_snapshot=null;
	
	--����� id_spanshot (���� �������� ���������� �������)
	SET @id_snapshot= (	SELECT l.id_spanshot
	                      FROM dbo.LogisticSnapshots l
	                     WHERE l.isDocsLoaded = 1
	                       AND l.ActualDateBeg = @ActualDateBeg
						   AND l.ActualDateEnd = @ActualDateEnd)

    IF (@id_snapshot is null)--���� �� ����	
	BEGIN
	    --����� id_spanshot (���� �������� ��������� �������)
	    SET @id_snapshot=(SELECT l.id_spanshot
	                        FROM dbo.LogisticSnapshots l	                     
	                       WHERE l.ActualDateBeg = @ActualDateBeg
						     AND l.ActualDateEnd = @ActualDateEnd)
        IF (@id_snapshot is null)
		BEGIN
		 -- ������� ����� ������ � LogisticSnapshots 
		  INSERT INTO [dbo].[LogisticSnapshots]
           ([shapshot_data],[isRestsLoaded],[isDocsLoaded],[ActualDateBeg],[ActualDateEnd])
          VALUES
           (CONVERT (date, CURRENT_TIMESTAMP), 0, 1, @ActualDateBeg, @ActualDateEnd);	
		   SET @id_snapshot = @@IDENTITY; 		   
		END
		ELSE
		BEGIN
		  --���������� id_snapshot, �.�. �������� ���������� ����� �����������
		  UPDATE dbo.LogisticSnapshots 
		     SET dbo.LogisticSnapshots.isDocsLoaded = 1
		   WHERE dbo.LogisticSnapshots.id_spanshot=@id_snapshot
		     AND dbo.LogisticSnapshots.shapshot_data = CONVERT (date, CURRENT_TIMESTAMP)
		END

	END
	
	-- ������� ����������
	INSERT INTO [dbo].[DocsSnapshot]
			([id_snapshot],      [InnerPartyKey],        [Producer]
			,[Product],          [Shifr],                [Figure]
			,[Measure],          [Weight],               [pType]
			,[pGroup],           [pRecieverPlan],        [pRecieverFact]
			,[RecieverGroup],    [InnerOrderNum],        [OrderedBy]
			,[OrderNum],         [QuantityPrihod],       [PE_Prihod]
			,[PF_Prihod],        [PCP_Prihod],           [PCPC_Prihod]
			,[FCP_Prihod],       [FCPC_Prihod],          [BP_Prihod]
			,[PE_Rashod],        [PF_Rashod],            [PCP_Rashod]
			,[PCPC_Rashod],      [FCP_Rashod],           [FCPC_Rashod]
			,[BP_Rashod],        [QuantityRashod],       [Storage]
			,[StorageCity],      [StorageCountry],       [�enter]
			,[BalanceKeeper],    [ReadyForSaleStatus],   [ReserveStatus]
			,[ProduceDate],      [ReconcervationDate],   [TermOnStorage]
			,[PrihodDocType],    [PrihodDocNum],         [PrihodDocDate]
			,[RashodDocType],    [RashodDocNum],         [RashodDocDate]
			,[BalanceCurrency],  [CurrencyIndexToUAH])
		VALUES
			(@id_snapshot,      @InnerPartyKey,      @Producer,       
			 @Product,   		@Shifr,              @Figure,         
			 @Measure,			@Weight,             @pType,          
			 @pGroup,			@pRecieverPlan,      @pRecieverFact,  
			 @RecieverGroup,	@InnerOrderNum,      @OrderedBy,      
			 @OrderNum,			@QuantityPrihod,     @PE_Prihod,     
			 @PF_Prihod,		@PCP_Prihod,         @PCPC_Prihod,    
			 @FCP_Prihod,		@FCPC_Prihod,        @BP_Prihod,      
			 @PE_Rashod,		@PF_Rashod,          @PCP_Rashod,    
			 @PCPC_Rashod,		@FCP_Rashod,         @FCPC_Rashod,    
			 @BP_Rashod,		@QuantityRashod,     @Storage,        
			 @StorageCity,		@StorageCountry,     @�enter,         
			 @BalanceKeeper,    @ReadyForSaleStatus, @ReserveStatus,  
			 @ProduceDate,		@ReconcervationDate, @TermOnStorage,  
			 @PrihodDocType,	@PrihodDocNum,       @PrihodDocDate,  
			 @RashodDocType, 	@RashodDocNum,       @RashodDocDate,  
			 @BalanceCurrency,	@CurrencyIndexToUAH)
END
GO


