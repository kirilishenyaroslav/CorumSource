
/****** Object:  StoredProcedure [dbo].[LogImportErrorInsert]    Script Date: 15.05.2016 20:42:38 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[LogImportErrorInsert] 
@IsRests bit,
@NumRow int,
@ColumnName nvarchar(500),
@CommentError nvarchar(max),
@guidSession nvarchar(36)
AS
BEGIN
	SET NOCOUNT ON;
	--��������� ������� ���� ������ ��� �������
	INSERT INTO [dbo].[LogImportErrors]
           ([IsRests]
           ,[NumRow]
           ,[ColumnName]
           ,[CommentError]
		   ,[guidSession]
		   ,[DateWriteLog])
     VALUES
           (@IsRests,
			@NumRow,
			@ColumnName,
			@CommentError,
			@guidSession,
			CURRENT_TIMESTAMP)
END

GO


