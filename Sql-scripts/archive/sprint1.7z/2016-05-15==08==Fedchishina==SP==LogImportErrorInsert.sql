
/****** Object:  StoredProcedure [dbo].[RestsSnapshotInsert]    Script Date: 15.05.2016 20:43:09 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[RestsSnapshotInsert] 
@ActualDateBeg varchar(50),   @ActualDateEnd varchar(50),
@InnerPartyKey varchar(500),       @Producer varchar(500),       @Product varchar(100),
@Shifr varchar(50),                @Figure varchar(50),          @Measure varchar(50),
@Weight decimal(16,2),             @pType varchar(100),          @pGroup varchar(500),
@pRecieverPlan varchar(500),       @pRecieverFact varchar(500),  @RecieverGroup varchar(100),
@InnerOrderNum varchar(50),        @OrderedBy varchar(500),      @OrderNum varchar(50),
@QuantityBefore int,               @PE_Before decimal(18,2),     @PF_Before decimal(18,2),
@PCP_Before decimal(18,2),         @PCPC_Before decimal(18,2),   @FCP_Before decimal(18,2),
@FCPC_Before decimal(18,2),        @BP_Before decimal(18,2),     @PE_After decimal(18,2),
@PF_After decimal(18,2),           @PCP_After decimal(18,2),     @PCPC_After decimal(18,2),
@FCP_After decimal(18,2),          @FCPC_After decimal(18,2),    @BP_After decimal(18,2),
@QuantityAfter int,                @Storage varchar(100),        @StorageCity varchar(50),
@StorageCountry varchar(10),       @�enter varchar(100),         @BalanceKeeper varchar(100),
@ReadyForSaleStatus varchar(50),   @ReserveStatus varchar(50),   @ProduceDate varchar(50),
@ReconcervationDate varchar(50),   @TermOnStorage int,           @CreateByDoc varchar(100),
@CreateByDocNum varchar(50),       @CreateByDocDate varchar(50), @BalanceCurrency varchar(50),
@CurrencyIndexToUAH decimal(18,2)
AS
BEGIN
  -- ��������� ������� �������� (��� �������)
	
	SET NOCOUNT ON;
	DECLARE @id_snapshot INT;
	set @id_snapshot=null;
	
	--����� id_spanshot (���� �������� �������� �������)
	SET @id_snapshot= (	SELECT l.id_spanshot
	                      FROM dbo.LogisticSnapshots l
	                     WHERE l.isRestsLoaded = 1
	                       AND l.ActualDateBeg = @ActualDateBeg
						   AND l.ActualDateEnd = @ActualDateEnd)

    IF (@id_snapshot is null)--���� �� ����	
	BEGIN
	    --����� id_spanshot (���� �������� ��������� �������)
	    SET @id_snapshot=(SELECT l.id_spanshot
	                        FROM dbo.LogisticSnapshots l	                     
	                       WHERE l.ActualDateBeg = @ActualDateBeg
						     AND l.ActualDateEnd = @ActualDateEnd)
        IF (@id_snapshot is null)
		BEGIN
		 -- ������� ����� ������ � LogisticSnapshots 
		  INSERT INTO [dbo].[LogisticSnapshots]
           ([shapshot_data],[isRestsLoaded],[isDocsLoaded],[ActualDateBeg],[ActualDateEnd])
          VALUES
           (CONVERT (date, CURRENT_TIMESTAMP), 1, 0, @ActualDateBeg, @ActualDateEnd);	
		   SET @id_snapshot = @@IDENTITY; 		   
		END
		ELSE
		BEGIN
		  --���������� id_snapshot, �.�. �������� ���������� ����� �����������
		  UPDATE dbo.LogisticSnapshots 
		     SET dbo.LogisticSnapshots.isRestsLoaded = 1
		   WHERE dbo.LogisticSnapshots.id_spanshot=@id_snapshot
		     AND dbo.LogisticSnapshots.shapshot_data = CONVERT (date, CURRENT_TIMESTAMP)
		END

	END

	-- ������� ��������
    INSERT INTO [dbo].[RestsSnapshot]
           ([id_snapshot],     [InnerPartyKey],      [Producer],
            [Product],         [Shifr],              [Figure],
            [Measure],         [Weight],             [pType],
            [pGroup],          [pRecieverPlan],      [pRecieverFact],
            [RecieverGroup],   [InnerOrderNum],      [OrderedBy],
            [OrderNum],        [QuantityBefore],     [PE_Before],
            [PF_Before],       [PCP_Before],         [PCPC_Before],
            [FCP_Before],      [FCPC_Before],        [BP_Before],
            [PE_After],        [PF_After],           [PCP_After],
            [PCPC_After],      [FCP_After],          [FCPC_After],
            [BP_After],        [QuantityAfter],      [Storage],
            [StorageCity],     [StorageCountry],     [�enter],
            [BalanceKeeper],   [ReadyForSaleStatus], [ReserveStatus],
            [ProduceDate],     [ReconcervationDate], [TermOnStorage],
            [CreateByDoc],     [CreateByDocNum],     [CreateByDocDate],
            [BalanceCurrency], [CurrencyIndexToUAH])
     VALUES
           (@id_snapshot,       @InnerPartyKey,       @Producer,       
		    @Product,    		@Shifr ,              @Figure ,          
			@Measure,			@Weight,              @pType,          
			@pGroup,			@pRecieverPlan,       @pRecieverFact, 
			@RecieverGroup,		@InnerOrderNum,       @OrderedBy,      
			@OrderNum,			@QuantityBefore,      @PE_Before,	
			@PF_Before,			@PCP_Before,          @PCPC_Before,
			@FCP_Before,		@FCPC_Before,         @BP_Before,    
			@PE_After,  		@PF_After,            @PCP_After,     
			@PCPC_After,		@FCP_After,           @FCPC_After,   
			@BP_After, 			@QuantityAfter,       @Storage,     
			@StorageCity,		@StorageCountry,      @�enter,         
			@BalanceKeeper,		@ReadyForSaleStatus,  @ReserveStatus,   
			@ProduceDate,		@ReconcervationDate,  @TermOnStorage,           
			@CreateByDoc,		@CreateByDocNum,      @CreateByDocDate, 
			@BalanceCurrency,	@CurrencyIndexToUAH)
END
GO


