

/****** Object:  StoredProcedure [dbo].[SelectColumnValByDef]    Script Date: 15.05.2016 20:43:59 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[SelectColumnValByDef] 
	-- 0 - ������� � �����������
	-- 1 - ������� � ���������
	@IsRests BIT = 1,
	@ColumnName NVARCHAR(100)
AS
BEGIN
	SET NOCOUNT ON;

	DECLARE @TableName NVARCHAR(50);
	IF (@IsRests=1) 	
	 SET @TableName = 'RestsSnapshot';	
	ELSE 
	  SET @TableName='DocsSnapshot'
	
	  SELECT c.[ColumnName] as ColumnName, c.[ColumnValByDefault] as ColumnValByDefault
        FROM dbo.ColumnsValByDefault c
       WHERE c.[TableName] = @TableName
	     AND c.ColumnName=@ColumnName
    
END

GO


