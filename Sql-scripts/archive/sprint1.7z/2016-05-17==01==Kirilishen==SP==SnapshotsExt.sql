alter table LogisticSnapshots
add isDefaultForReports int;