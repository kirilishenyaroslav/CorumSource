

ALTER TABLE [dbo].[DocsSnapshot] DROP CONSTRAINT [FK_DocsSnapshot_LogisticSnapshots]
GO

ALTER TABLE [dbo].[DocsSnapshot]  WITH CHECK ADD  CONSTRAINT [FK_DocsSnapshot_LogisticSnapshots] FOREIGN KEY([id_snapshot])
REFERENCES [dbo].[LogisticSnapshots] ([id_spanshot])
ON DELETE CASCADE
GO

ALTER TABLE [dbo].[DocsSnapshot] CHECK CONSTRAINT [FK_DocsSnapshot_LogisticSnapshots]
GO


