

ALTER TABLE [dbo].[RestsSnapshot] DROP CONSTRAINT [FK_RestsSnapshot_LogisticSnapshots]
GO

ALTER TABLE [dbo].[RestsSnapshot]  WITH CHECK ADD  CONSTRAINT [FK_RestsSnapshot_LogisticSnapshots] FOREIGN KEY([id_snapshot])
REFERENCES [dbo].[LogisticSnapshots] ([id_spanshot])
ON DELETE CASCADE
GO

ALTER TABLE [dbo].[RestsSnapshot] CHECK CONSTRAINT [FK_RestsSnapshot_LogisticSnapshots]
GO


