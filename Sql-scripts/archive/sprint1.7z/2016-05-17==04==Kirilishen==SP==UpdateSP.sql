
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE SetSnapshotAsDefaultForReports 
	@snapshotId int
AS
BEGIN
	update [dbo].[LogisticSnapshots]
	   set [dbo].[LogisticSnapshots].isDefaultForReports=0;

	update [dbo].[LogisticSnapshots]
	   set [dbo].[LogisticSnapshots].isDefaultForReports=1
	 where [dbo].[LogisticSnapshots].id_spanshot=@snapshotId;
END
GO
