alter table LogImportErrors
add id int identity(1,1) not null;

GO

alter table LogImportErrors add primary key (id);

GO