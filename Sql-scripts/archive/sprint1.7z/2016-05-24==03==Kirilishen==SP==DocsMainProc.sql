

/****** Object:  StoredProcedure [dbo].[GetDocsDataBySnapshot]    Script Date: 5/24/2016 10:57:08 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


CREATE PROCEDURE [dbo].[GetDocsDataBySnapshot] 

	@snapShotId int,
	
	@FilterStorageId varchar(500)=null,
    @FilterCenterId varchar(500)=null,
    @FilterRecieverPlanId varchar(500)=null,
    @FilterRecieverFactId varchar(500)=null,
    @FilterKeeperId varchar(500)=null,
    @FilterProducerId varchar(500)=null,

    @UseStorageFilter int=0,
    @UseCenterFilter int=0,
    @UseRecieverPlanFilter int=0,
    @UseRecieverFactFilter int=0,
    @UseKeeperFilter int=0,
    @UseProducerFilter int=0
    
AS
BEGIN
     --SET FMTONLY ON;
     
	 SELECT DC.[idrow],               DC.[id_snapshot],        DC.[InnerPartyKey],   DC.[Producer],       DC.[Product],            DC.[Shifr],
	        DC.[Figure],              DC.[Measure],            DC.[Weight],          DC.[pType],          DC.[pGroup],             DC.[pRecieverPlan],
	        DC.[pRecieverFact],       DC.[RecieverGroup],      DC.[InnerOrderNum],   DC.[OrderedBy],      DC.[OrderNum],           DC.[Storage],             
			DC.[StorageCity],         DC.[StorageCountry],     DC.[�enter],          DC.[BalanceKeeper],  DC.[ReadyForSaleStatus], DC.[ReserveStatus],       
			DC.[ProduceDate],         DC.[ReconcervationDate], DC.[TermOnStorage], 
			  
			DC.[PrihodDocType] AS DocType,  
			DC.[PrihodDocNum]  AS DocNum,       
			DC.[PrihodDocDate] AS DocDate,     

			DC.[BalanceCurrency],     DC.[CurrencyIndexToUAH],
	        
	        DC.[QuantityPrihod]  AS Quantity,   
	        DC.[PE_Prihod]       AS PE,
	        DC.[PF_Prihod]       AS PF,
	        DC.[PCP_Prihod]      AS PCP,
	        DC.[PCPC_Prihod]     AS PCPC,
            DC.[FCP_Prihod]      AS FCP,          
            DC.[FCPC_Prihod]     AS FCPC,
            DC.[BP_Prihod]       AS BP,
			1 AS ISPrihod
            
       FROM [Corum].[dbo].[DocsSnapshot] DC
     
      WHERE (DC.id_snapshot=@snapShotId)
	    AND (LEN(DC.RashodDocType)=0)
		AND (LEN(DC.PrihodDocType)>0)
        AND ((@UseStorageFilter=0)     OR ((@UseStorageFilter=1)     and(DC.Storage=@FilterStorageId)))
        AND ((@UseCenterFilter=0)      OR ((@UseCenterFilter=1)      and(DC.�enter=@FilterCenterId))) 
        AND ((@UseRecieverPlanFilter=0)OR ((@UseRecieverPlanFilter=1)and(DC.pRecieverPlan=@FilterRecieverPlanId)))
        AND ((@UseRecieverFactFilter=0)OR ((@UseRecieverFactFilter=1)and(DC.pRecieverFact=@FilterRecieverFactId)))
        AND ((@UseKeeperFilter=0)      OR ((@UseKeeperFilter=1)      and(DC.BalanceKeeper=@FilterKeeperId))) 
        AND ((@UseProducerFilter=0)    OR ((@UseProducerFilter=1)    and(DC.Producer=@FilterProducerId)))
    
    UNION

	SELECT  DC.[idrow],               DC.[id_snapshot],        DC.[InnerPartyKey],   DC.[Producer],       DC.[Product],            DC.[Shifr],
	        DC.[Figure],              DC.[Measure],            DC.[Weight],          DC.[pType],          DC.[pGroup],             DC.[pRecieverPlan],
	        DC.[pRecieverFact],       DC.[RecieverGroup],      DC.[InnerOrderNum],   DC.[OrderedBy],      DC.[OrderNum],           DC.[Storage],             
			DC.[StorageCity],         DC.[StorageCountry],     DC.[�enter],          DC.[BalanceKeeper],  DC.[ReadyForSaleStatus], DC.[ReserveStatus],       
			DC.[ProduceDate],         DC.[ReconcervationDate], DC.[TermOnStorage], 
			  
			DC.[RashodDocType] AS DocType,  
			DC.[RashodDocNum]  AS DocNum,       
			DC.[RashodDocDate] AS DocDate,
			     
			DC.[BalanceCurrency],     DC.[CurrencyIndexToUAH],
	        
	        DC.[QuantityRashod]  AS Quantity,   
	        DC.[PE_Rashod]       AS PE,
	        DC.[PF_Rashod]       AS PF,
	        DC.[PCP_Rashod]      AS PCP,
	        DC.[PCPC_Rashod]     AS PCPC,
            DC.[FCP_Rashod]      AS FCP,          
            DC.[FCPC_Rashod]     AS FCPC,
            DC.[BP_Rashod]       AS BP,
			0 AS ISPrihod
            
       FROM [Corum].[dbo].[DocsSnapshot] DC
     
      WHERE (DC.id_snapshot=@snapShotId)
	    AND (LEN(DC.RashodDocType)>0)
		AND (LEN(DC.PrihodDocType)>0)
        AND ((@UseStorageFilter=0)     OR ((@UseStorageFilter=1)     and(DC.Storage=@FilterStorageId)))
        AND ((@UseCenterFilter=0)      OR ((@UseCenterFilter=1)      and(DC.�enter=@FilterCenterId))) 
        AND ((@UseRecieverPlanFilter=0)OR ((@UseRecieverPlanFilter=1)and(DC.pRecieverPlan=@FilterRecieverPlanId)))
        AND ((@UseRecieverFactFilter=0)OR ((@UseRecieverFactFilter=1)and(DC.pRecieverFact=@FilterRecieverFactId)))
        AND ((@UseKeeperFilter=0)      OR ((@UseKeeperFilter=1)      and(DC.BalanceKeeper=@FilterKeeperId))) 
        AND ((@UseProducerFilter=0)    OR ((@UseProducerFilter=1)    and(DC.Producer=@FilterProducerId)))
    

     
        
END

GO


