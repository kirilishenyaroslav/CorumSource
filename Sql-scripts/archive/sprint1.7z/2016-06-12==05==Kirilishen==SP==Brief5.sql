
/****** Object:  UserDefinedFunction [dbo].[GetShipsOnDate]    Script Date: 6/12/2016 08:52:09 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE FUNCTION [dbo].[GetShipsOnDate]( 
    @PeriodDateBeg datetime,
	@PeriodDateEnd datetime,
	@OnDate datetime,

    @snapShotId int,
	@FilterStorageId varchar(500)=null,
    @FilterCenterId varchar(500)=null,
    @FilterRecieverPlanId varchar(500)=null,
    @FilterRecieverFactId varchar(500)=null,
    @FilterKeeperId varchar(500)=null,
    @FilterProducerId varchar(500)=null,

    @UseStorageFilter int=0,
    @UseCenterFilter int=0,
    @UseRecieverPlanFilter int=0,
    @UseRecieverFactFilter int=0,
    @UseKeeperFilter int=0,
    @UseProducerFilter int=0
)
RETURNS @RestInfoTable TABLE
   (
       [ShipOnDate_Quantity]     int,
       [ShipOnDate_Mass]         decimal(16,2),
       [ShipOnDate_PE]           decimal(16,2),       
       [ShipOnDate_PF]           decimal(16,2),          
       [ShipOnDate_PCP]          decimal(16,2),          
       [ShipOnDate_PCPC]         decimal(16,2), 
       [ShipOnDate_FCP]          decimal(16,2),         
       [ShipOnDate_FCPC]         decimal(16,2),
	   [ShipOnDate_BP]           decimal(16,2)
   )
AS
BEGIN

   WITH tempRestInfo (Quantity,  Mass,    PE,    PF,   PCP,   PCPC,   FCP,   FCPC,  BP)
   AS
     (
		select  SUM(DC.QuantityRashod), 
		        SUM(DC.QuantityRashod*DC.Weight),
				SUM(DC.PE_Rashod),
				SUM(PF_Rashod),
				SUM(PCP_Rashod),
				SUM(PCPC_Rashod),
				SUM(FCP_Rashod),
				SUM(FCPC_Rashod),
				SUM(BP_Rashod)
		   FROM [dbo].[DocsSnapshot] DC
              WHERE (DC.id_snapshot=@snapShotId)
			    AND (DC.QuantityPrihod=0)
		        AND (DC.QuantityRashod!=0)
			    AND (convert(datetime, DC.RashodDocDate, 104) = @OnDate)
                AND ((@UseStorageFilter=0)        OR ((@UseStorageFilter=1)       and(DC.Storage=@FilterStorageId)))
                AND ((@UseCenterFilter=0)         OR ((@UseCenterFilter=1)        and(DC.�enter=@FilterCenterId))) 
                AND ((@UseRecieverPlanFilter=0)   OR ((@UseRecieverPlanFilter=1)  and(DC.pRecieverPlan=@FilterRecieverPlanId)))
                AND ((@UseRecieverFactFilter=0)   OR ((@UseRecieverFactFilter=1)  and(DC.pRecieverFact=@FilterRecieverFactId)))
                AND ((@UseKeeperFilter=0)         OR ((@UseKeeperFilter=1)        and(DC.BalanceKeeper=@FilterKeeperId))) 
                AND ((@UseProducerFilter=0)       OR ((@UseProducerFilter=1)      and(DC.Producer=@FilterProducerId)))

     )

   INSERT @RestInfoTable
        SELECT SUM(D.Quantity), 
               SUM(D.Mass),
               SUM(D.PE),
               SUM(D.PF),
               SUM(D.PCP),
               SUM(D.PCPC),
               SUM(D.FCP),
               SUM(D.FCPC),
               SUM(D.BP)
          FROM tempRestInfo D
   
   RETURN
END
GO


